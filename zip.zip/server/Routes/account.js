const express = require("express")
const accountRoutes = express.Router();
const fs = require('fs');

const dataPath = './Details/products.json' 

// util functions 

const saveAccountData = (data) => {
    const stringifyData = JSON.stringify(data)
    fs.writeFileSync(dataPath, stringifyData)
}

const getAccountData = () => {
    const jsonData = fs.readFileSync(dataPath)
    return JSON.parse(jsonData)    
}


const findIndexById = (id, data) => {
  let index = -1;
  for (let i = 0; i < data.length; i++) {
      if (data[i].id === id) {
          index = i;
          break;
      }
  }

  return index;
}
// reading the data
accountRoutes.get('/account', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
      if (err) {
        throw err;
      }

      res.send(JSON.parse(data));
    });
  });


  accountRoutes.post('/account/addaccount', (req, res) => {
   
    var existAccounts = getAccountData()
    const newAccountId = Math.floor(100000 + Math.random() * 900000)
    console.log(existAccounts, req.body);
    existAccounts.push(req.body)
     
    //console.log(existAccounts);

    saveAccountData(existAccounts);
    res.send(existAccounts)
})

accountRoutes.post('/account/savetiles', (req, res) => {
   
  // var existAccounts = getAccountData()
  // const newAccountId = Math.floor(100000 + Math.random() * 900000)
  // console.log(existAccounts, req.body);
  // existAccounts.push(req.body)
   
  // //console.log(existAccounts);

  saveAccountData(req.body);
  res.send(req.body)
})
// Read - get all accounts from the json file
accountRoutes.get('/account/list', (req, res) => {
  const accounts = getAccountData()
  res.send(accounts)
})

// Update - using Put method
accountRoutes.put('/account/:id', (req, res) => {
   var existAccounts = getAccountData()
   fs.readFile(dataPath, 'utf8', (err, data) => {
    const accountId = req.params['id'];
    const acc = req.body
    // existAccounts[accountId] = req.body;
    //console.log(findIndexById(accountId, data), req.body)
    existAccounts.forEach(function(e) {
      if(acc.id && acc.id == e.id) {
        for(var i in acc) e[i] = acc[i]
      }
    })

    saveAccountData(existAccounts);
    res.send(acc)
  }, true);
});

//delete - using delete method
accountRoutes.delete('/account/delete/:id', (req, res) => {
   fs.readFile(dataPath, 'utf8', (err, data) => {
    var existAccounts = getAccountData()

    const userId = req.params['id'];
    var removeIndex = existAccounts.map(item => item.id).indexOf(userId);

    ~removeIndex && existAccounts.splice(removeIndex, 1);
    // delete existAccounts[userId];  
    saveAccountData(existAccounts);
    res.send(existAccounts)
  }, true);
})
module.exports = accountRoutes