
function getProducts() {
    return fetch('/account/list').then(res => res.json());
}
function addProduct(prod) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prod)
    };
    return fetch('/account/addaccount', requestOptions)
        .then(response => response.json())
}

function updateProduct(prod) {
    const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prod)
    };
    return fetch(`/account/${prod.id}`, requestOptions)
        .then(response => response.json())
}
function saveProducts(prod) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prod)
    };
    return fetch('/account/savetiles', requestOptions)
        .then(response => response.json())
}
function deleteProductSS(prod) {
    const requestOptions = {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    };
    return fetch(`/account/delete/${prod.id}`, requestOptions)
        .then(response => response.json())
}
export {updateProduct, addProduct, getProducts, deleteProductSS, saveProducts};