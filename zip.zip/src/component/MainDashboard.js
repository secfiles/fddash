import React, { useState, useEffect, useRef } from 'react';
import { classNames } from 'primereact/utils';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { getProducts, addProduct, updateProduct, deleteProductSS, saveProducts } from './ProductService';
import { Toast } from 'primereact/toast';
import { Button } from 'primereact/button';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Checkbox } from 'primereact/checkbox';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Dropdown } from 'primereact/dropdown';
import { SelectButton } from 'primereact/selectbutton';
import { Chip } from 'primereact/chip';

const columns = [
    {label: 'Status', value: 'status'},
    // {label: 'Customer', value: 'customerName'},
    // {label: 'Secure', value: 'secure'},
    // {label: 'Country', value: 'country'},
    {label: 'Region', value: 'region'},
    // {label: 'Network', value: 'networkProduct'},
    {label: 'Age', value: 'age'},
    // {label: 'User', value: 'user'}
];
const includes = [
    {label: 'Include', value: 'INCLUDE'},
    {label: 'Exclude', value: 'EXCLUDE'},
]
const MainDashboard = () => {
    let emptyProduct = {
        "id": null,
        "title": '',
        "description": '',
        "metrics": []         
    };


    const [products, setProducts] = useState(null);
    const [productDialog, setProductDialog] = useState(false);
    const [deleteProductDialog, setDeleteProductDialog] = useState(false);
    const [product, setProduct] = useState(emptyProduct);
    const [expandedRows, setExpandedRows] = useState(null);
    const [expandedSubRows, setExpandedSubRows] = useState(null);
    const [submitted, setSubmitted] = useState(false);
    const toast = useRef(null);
    const dt = useRef(null);

    useEffect(() => {
        getProducts().then(data => {
            setProducts(data)
        });
    }, []);



    const openNew = () => {
        setProduct(emptyProduct);
        setSubmitted(false);
        setProductDialog(true);
    }

    const hideDialog = () => {
        setSubmitted(false);
        setProductDialog(false);
    }

    const hideDeleteProductDialog = () => {
        setDeleteProductDialog(false);
    }    

    const saveProduct = () => {
        setSubmitted(true);       
        if (product.title.trim()) {
            let _products = [...products];
            let _product = {...product};
            if (product.id) {
                const index = findIndexById(product.id);
                _product.metrics.forEach((metric) => {
                    if(!metric.id) {
                        metric.id = createId();
                    }
                })
                _products[index] = _product;
                toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Updated', life: 3000 });
                updateProduct(_product)
            }
            else {
                _product.id = createId();
                _product.metrics.forEach((metric) => {
                    metric.id = createId();
                })
                _products.push(_product);
                addProduct(_product)
                toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Created', life: 3000 });
            }
            
            setProducts(_products);
            setProductDialog(false);
            setProduct(emptyProduct);        
        }
    }

    const editProduct = (product) => {
        setProduct({...product});
        setProductDialog(true);
    }

    const confirmDeleteProduct = (product) => {
        setProduct(product);
        setDeleteProductDialog(true);
    }

    const deleteProduct = () => {
        deleteProductSS(product)
        let _products = products.filter(val => val.id !== product.id);
        setProducts(_products);        
        setDeleteProductDialog(false);
        setProduct(emptyProduct);
        toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Deleted', life: 3000 });
    }

    const findIndexById = (id) => {
        let index = -1;
        for (let i = 0; i < products.length; i++) {
            if (products[i].id === id) {
                index = i;
                break;
            }
        }

        return index;
    }

    const createId = () => {
        let id = '';
        let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (let i = 0; i < 5; i++) {
            id += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return id;
    }

    const onInputChange = (e, name) => {
        const val = (e.target && e.target.value) || '';
        let _product = {...product};
        _product[`${name}`] = val;

        setProduct(_product);
    }

    const onMetricInputChange = (e, name, i) => {
        const val = (e.target && e.target.value) || '';

        let _product = {...product};

        if(name === "metricTitle") {
            _product.metrics.map(function(metric, index) {
                if(i === index) {
                    metric.title = val;
                }
                return metric;
            })
        }
        if(name === "metricDescription") {
            _product.metrics.map(function(metric, index) {
                if(i === index) {
                    metric.description = val;
                }
                return metric;
            })
        }
        if(name === "metricEmphasized") {
            _product.metrics.map(function(metric, index) {
                if(i === index) {
                    metric.emphasized = e.checked;
                }
                return metric;
            })
        }

        setProduct(_product);
    }    

    const actionBodyTemplate = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" className="p-button-rounded p-button-success mr-2" onClick={() => editProduct(rowData)} />
                <Button icon="pi pi-trash" className="p-button-rounded p-button-danger" onClick={() => confirmDeleteProduct(rowData)} />
            </React.Fragment>
        );
    }

    const header = (
        <div className="flex flex-column md:flex-row md:align-items-center justify-content-between">
            <span className="p-input-icon-left w-full md:w-auto">
                Tiles
            </span>
            <div className="mt-3 md:mt-0 flex justify-content-end">
                <Button icon="pi pi-plus" className="mr-2 p-button-rounded" onClick={openNew} tooltip="New" tooltipOptions={{position: 'bottom'}} />
            </div>
        </div>
    );
    const productDialogFooter = (
        <React.Fragment>
            <Button label="Cancel" icon="pi pi-times" className="p-button-text" onClick={hideDialog} />
            <Button label="Save" icon="pi pi-check" onClick={saveProduct} />
        </React.Fragment>
    );

    const deleteProductDialogFooter = (
        <React.Fragment>
            <Button label="No" icon="pi pi-times" className="p-button-text" onClick={hideDeleteProductDialog} />
            <Button label="Yes" icon="pi pi-check" className="p-button-text" onClick={deleteProduct} />
        </React.Fragment>
    );


    const addMetric = (e, product) => {
        let _product = {...product};
        _product.metrics.push({
            "id": createId(),
            "title": '',
            "description": '',
            "value": 0, 
            "emphasized": false, 
            "filters": {
                
            }
        })
        setProduct(_product)
    }
    const setFilterColumn = (e, index, metricIndex, oldValue) => {
        let _product = {...product}
        _product.metrics.map(function(metric, i) {
            if(i === metricIndex) {
                delete metric.filters[oldValue]
                metric.filters[e] = {
                    "inclusionType": '',
                    "values": []
                }
                
            }
            return metric;
        })
        setProduct(_product)
    }
    const addMetricFilter = (e, metricIndex) => {
        let _product = {...product}
        _product.metrics.map(function(metric, i) {
            if(i === metricIndex) {
                metric.filters['customFilter'] = {
                    "inclusionType": '',
                    "values": []
                }
            }
            return metric
        })
        setProduct(_product)
    }

    const addFilterValues = (e, index, metricIndex, column)  => {
        const val = (e.target && e.target.value) || '';
        let _product = {...product}
        _product.metrics.map(function(metric, i) {
            if(i === metricIndex) {
                metric.filters[column].values = val.split(", ")
            }
            return metric
        })
        setProduct(_product)
    }

    const updateCustomerSpecific = (e, metricIndex)  => {
        let _product = {...product}
        _product.metrics.map(function(metric, i) {
            if(i === metricIndex) {
                metric.perUser = e.checked
            }
            return metric
        })
        setProduct(_product)
    }

    const setInclusionValue = (e, index, metricIndex, column)  => {
        let _product = {...product}
        _product.metrics.map(function(metric, i) {
            if(i === metricIndex) {
                metric.filters[column].inclusionType = e
            }
            return metric
        })
        setProduct(_product)
    }

    const removeMetric = (e, index, metric)  => {
        let _product = {...product}
        let filteredProduct = _product.metrics.filter(val => val.id !== metric.id);
        _product.metrics = filteredProduct

        updateProduct(_product)
        setProduct(_product)
    }

    const removeFilters = (e, index, filter, metric) => {
        let _product = {...product}
        _product.metrics.map(function(m, i) {
            if(i === index) {
                delete metric.filters[filter]
            }
            return metric
        })
        setProduct(_product)
    }
    
    const TileMetric = (prop) => {
        return(
        <div>
            {prop && <h5>Metrics</h5>}
            {prop && prop.metrics && <Accordion>
                {prop.metrics.map(function(object, i){
                    console.log(object)
                    return <AccordionTab  key={i}  header={object.title || "Update Metric Title"}>
                        <div className="formgrid grid">
                            <div className="field col">
                                <InputText id="title" placeholder="Title"  key={object.id} required value={object.title} onChange={(e) => onMetricInputChange(e, 'metricTitle', i)}  />
                            </div>
                            <div className="field col">
                                <InputText id="description" placeholder="Description" value={object.description} onChange={(e) => onMetricInputChange(e, 'metricDescription', i)}  />
                            </div>
                            <div className="field-radiobutton col">
                                <Checkbox inputId="category4" name="emphasized" value="Ephasized" onChange={(e) => onMetricInputChange(e, 'metricEmphasized', i)} checked={object.emphasized} />
                                <label htmlFor="category4">Emphasized</label>
                            </div>
                            <div className="field-radiobutton col">
                                <Checkbox inputId="userCheckbox" name="category" value="Customer" onChange={(e) => updateCustomerSpecific(e, i)} checked={object.perUser} />
                                <label htmlFor="userCheckbox">Per User</label>
                            </div>
                            <Button icon="pi pi-trash" className="p-button-rounded p-button-danger" onClick={(e) => removeMetric(e, i, object)}  tooltip="Remove Metric"/>
                        </div>
                        <h5>Filters</h5>
                        {object.filters && Object.keys(object.filters).map(function(filter, idx) {
                            return <div className="formgrid grid" key={idx}>
                                        <div className="field col">
                                            <Dropdown value={filter} options={columns} onChange={(e) => setFilterColumn(e.value, idx, i, filter)} placeholder="Column"/>
                                        </div>
                                        <div className="field col">
                                            <InputText value={object.filters[filter].values.join(", ")} onChange={(e) => addFilterValues(e, idx, i, filter)} placeholder="Add list of values"/>
                                        </div>
                                        <div className="field-radiobutton col">
                                            <SelectButton id="inclusionselect" value={object.filters[filter].inclusionType} options={includes} onChange={(e) => setInclusionValue(e.value, idx, i, filter)}></SelectButton>
                                        </div>
                                        
                                        <Button icon="pi pi-trash" className="p-button-rounded p-button-danger" onClick={(e) => removeFilters(e, i, filter, object)}  tooltip="Remove Filter"/>

                                       
                                </div>
                        })}
                        <div className="field col-3 col-offset-9">
                            <Button icon="pi pi-plus" className="mr-2 p-button" label="Add Filter" onClick={(e) => addMetricFilter(e, i)} tooltip="Add Filter" tooltipOptions={{position: 'bottom'}} />
                        </div>
                    </AccordionTab >
                   ;
            })
            }
            </Accordion>}

            <div className="field col-3 col-offset-9">
                <Button icon="pi pi-plus" className="mr-2 p-button"  label="Add Metric" onClick={(e) => addMetric(e, product)} tooltip="Add Metric" tooltipOptions={{position: 'bottom'}} />
            </div>
        </div>
    )};

    const emphasizedBodyTemplate = (rowData) => {
        var icon = rowData.emphasized? "pi pi-check" : "pi pi-times"
        var buttonClass = rowData.emphasized ? "p-button-text p-button-sm p-button-rounded p-button-success" : "p-button-sm p-button-text p-button-rounded p-button-danger"
        return <Button icon={icon} disabled className={buttonClass} />;
    }
    const perUserBodyTemplate = (rowData) => {
        var icon = rowData.perUser ? "pi pi-check" : "pi pi-times"
        var buttonClass = rowData.perUser ? "p-button-text p-button-sm p-button-rounded p-button-success" : "p-button-sm p-button-text p-button-rounded p-button-danger"
        return <Button icon={icon} disabled className={buttonClass} />;
    }
    const subRowExpansionTemplate = (object) => {
        return (
            <div className="orders-subtable">
                <h5>Filters</h5>
                {object.filters && Object.keys(object.filters).map(function(filter, idx) {
                    return <div className="grid" key={idx}>
                                <div className="col-1">
                                    {filter}
                                </div>
                                <div className="col">
                                    {object.filters[filter].values && object.filters[filter].values.map(function(val, i) {
                                        return <Chip label={val}  className="mr-2" />
                                    })}
                                </div>
                                <div className="col-2">
                                    {object.filters[filter].inclusionType}
                                </div>

                                
                                
                        </div>
                })}
                
            </div>
        );
    }

    const rowExpansionTemplate = (data) => {
        return (
            <div className="orders-subtable">
                <h5>Metrics</h5>
                <DataTable value={data.metrics} responsiveLayout="scroll" expandedRows={expandedSubRows}  size="small"
                 rowExpansionTemplate={subRowExpansionTemplate} onRowToggle={(e) => setExpandedSubRows(e.data)} onRowReorder={(e) => onSubRowReorder(e, data)} 
                    >
                    <Column field="id" style={{ width: '32px' }} expander></Column>
                    <Column field="id" style={{ width: '32px' }} rowReorder   ></Column>
                    <Column field="title" header="Title" style={{ maxWidth: '5rem' }}></Column>
                    <Column field="description" header="Description"></Column>
                    <Column field="perUser" header="Per User" body={perUserBodyTemplate} style={{ maxWidth: '1rem' }}></Column>
                    <Column field="emphasized" header="Emphasized" body={emphasizedBodyTemplate} style={{ maxWidth: '1rem' }}></Column>
                </DataTable>
                
            </div>
        );
    }
    const onRowReorder = (e) => {
        saveProducts(e.value)
        setProducts(e.value);
        toast.current.show({severity:'success', summary: 'Rows Reordered', life: 3000});
    }
    const onSubRowReorder = (e, data) => {
        let _product = data
        // console.log(e.value, data, product)
        _product.metrics = e.value;
        updateProduct(_product)
        setProduct(_product)
        // saveProducts(e.value)
        // setProducts(e.value);
        // toast.current.show({severity:'success', summary: 'Rows Reordered', life: 3000});
    }
    return (
        <div className="surface-card p-4 ">
            <Toast ref={toast} />
            <DataTable ref={dt} value={products} expandedRows={expandedRows} onRowToggle={(e) => setExpandedRows(e.data)}
                stripedRows  onRowReorder={onRowReorder} 
                dataKey="id" rows={1000}  rowExpansionTemplate={rowExpansionTemplate}
                header={header} responsiveLayout="scroll">
                <Column field="id" style={{ width: '32px' }}   expander ></Column>
                <Column field="id" style={{ width: '32px' }} rowReorder   ></Column>
                <Column field="title" header="Title" sortable style={{ maxWidth: '8rem' }}></Column>
               
                <Column field="description" header="Description" sortable style={{ minWidth: '10rem' }}></Column>
                <Column body={actionBodyTemplate} exportable={false} style={{ maxWidth: '5rem', textAlign: "right" }}></Column>
            </DataTable>

            <Dialog visible={productDialog} breakpoints={{'960px': '75vw', '640px': '100vw'}} style={{width: '40vw'}} header="Tile Details" modal className="p-fluid" footer={productDialogFooter} onHide={hideDialog}>
                <div className="field">
                    <label htmlFor="name">Name</label>
                    <InputText id="name" value={product.title} onChange={(e) => onInputChange(e, 'title')} required autoFocus className={classNames({ 'p-invalid': submitted && !product.title })} />
                    {submitted && !product.title && <small className="p-error">Title is required.</small>}
                </div>
                <div className="field">
                    <label htmlFor="description">Description</label>
                    <InputTextarea id="description" value={product.description} onChange={(e) => onInputChange(e, 'description')} required rows={3} cols={20} />
                </div>
                
                {TileMetric(product)}
                
            </Dialog>

            <Dialog visible={deleteProductDialog} style={{ width: '450px' }} header="Confirm" modal footer={deleteProductDialogFooter} onHide={hideDeleteProductDialog}>
                <div className="flex align-items-center justify-content-center">
                    <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem'}} />
                    {product && <span>Are you sure you want to delete <b>{product.title}</b>?</span>}
                </div>
            </Dialog>

        </div>
    );
}

export default  MainDashboard;

